import React, { Component } from 'react';
import './Navigation.scss';

class Navigation extends Component {
  render() {
    return (
      <div className="Navigation">
        <p className="title">Git-Auto-Deploy</p>
      </div>
    );
  }
}

export default Navigation;
