#!/usr/bin/python
print('This is a image usage example app.')
