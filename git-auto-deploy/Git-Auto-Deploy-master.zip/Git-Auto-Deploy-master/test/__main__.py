
if __name__ == '__main__':
    from test_parsers import main
    main()
