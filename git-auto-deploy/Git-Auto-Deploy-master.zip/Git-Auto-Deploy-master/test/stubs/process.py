class ProcessWrapper():

    @staticmethod
    def call(*args, **kwargs):
        """Fake process call"""
        return 0
